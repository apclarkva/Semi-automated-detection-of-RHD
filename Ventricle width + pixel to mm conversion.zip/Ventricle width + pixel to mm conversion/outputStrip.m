function [ output_args ] = outputStrip( mmFive )
%OUTPUTSTRIP Summary of this function goes here
%   Detailed explanation goes here








end



pt1 = [x(1),y(1)];
pt2 = [x(2),y(2)];

distFrom = floor(norm(pt1-pt2));
vect = pt1-pt2;
unitV = vect./norm(vect);
pix = [];
for i = 1:distFrom
    currPt = floor(pt2+i*unitV);
    pix = [pix;max(a(currPt(2),currPt(1),:,1))]; 
end


