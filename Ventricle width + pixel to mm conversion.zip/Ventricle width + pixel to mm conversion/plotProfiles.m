function [ output_args ] = plotProfiles( dcmimg )
%PLOTPROFILES Summary of this function goes here
%   Detailed explanation goes here

% outputs the pixel to mm conversion
% outputs the the point at five down the edge
[pixToMM, mmFive] = calibrateIMstack(dcmimg);

% make function to take in mm five and output strip of averaged
% points
strip = outputStrip(mmFive);

figure;plot


end

