function [ pixTOmm, mmFive ] = calibrateIMstack( imdic )
%CALIBRATEIMSTACK takes in movie and exports a conversion in units of
%pixels/mm

% bring in reference to image
img = dicomread(imdic);
img = img(:,:,:,1);
imageSize = size(img);
numColumns = imageSize(2);

numStart = ceil(numColumns/2);

dir = [];

if img(1,1,3) > 50;
    i = 2;
    while img(i,1,3) > 50
        i = i+1;
    end
    xVal = i+3;
    dir = 1;
else
    xVal = 5;
end

pixIntL = 0;
pixIntR = 0;
i = 0;

% determine which angle the start line is
while (pixIntL < 50)&&(pixIntR<50)
    pixIntL = img(xVal,numStart - i);
    pixIntR = img(xVal,numStart + i);
    i = i+1;
end
% If it is the left side, then I will find distance down left side
if pixIntL >50
    startPt = [xVal,numStart-i];
    if isempty(dir)
        dir = -1;
    end
    numMM = 50;
elseif pixIntR>50
    startPt = [xVal,numStart+i];
    if isempty(dir)
        dir = 1;
    end
    numMM = 10;
end
pixInt = 0;
currPt = [startPt(1)+10, startPt(2)+dir*10];

while pixInt < 100
    currPt = currPt + [1,dir];
    pixInt = img(currPt(1),currPt(2));
end

if dir == 1 %this is 50 mm on correct side
    vect = currPt-startPt;
    vect = [vect(1),-vect(2)];
    currPt = startPt + vect.*5;
end

dist = norm(currPt-startPt);
imshow(img);hold on;
s = [startPt;currPt];
plot(s(:,2),s(:,1));
pixTOmm = dist/numMM;
mmFive = s;
end

