function [ output_args ] = findEdge( input_args )
%FINDEDGE Summary of this function goes here
%   Detailed explanation goes here


end

