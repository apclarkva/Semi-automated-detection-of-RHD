function [  ] = Borders( imDic )
close all;clc;
% img = dicomread(imDic);
% img = img(:,:,1,:);
% imgNum = 1;
% max = length(img(1,1,1,:));

fig = figure;
data.imgPlot = imshow(img(:,:,1,imgNum));

data.contPlot1 = [];
data.contPlot2 = [];
data.contPlot3 = [];
data.interPlot1 = [];
data.interPlot2 = [];
data.interPlot3 = [];

%-------------------------------------------
button = 0;
while button ~= 1
    [x,y,button] = ginput(1);
    pt1 = [x,y];
end
button = 0;
while button ~= 1
    [x,y,button] = ginput(1);
    pt2 = [x,y];
end
button = 0;
while button ~= 1
    [x,y,button] = ginput(1);
    pt3 = [x,y];
end
%--------------------------------------------


pts = [pt1;pt2;pt3];
data.imgNum =imgNum;
data.pts = pts;
data.max = max;
data.img = img;

set(fig,'UserData',data);
set(fig,'WindowKeyPressFcn',{@shuffle});


end

function shuffle(keyNum,info)
fig = gcf;
data = get(fig,'UserData');
pts = data.pts;
imgNum = data.imgNum;
key = info.Key;
max = data.max;
img = data.img;

if isequal(key,'rightarrow')
    if imgNum == max
       imgNum = 1; 
    else
       imgNum = imgNum + 1; 
    end
elseif isequal(key,'leftarrow')
    if imgNum == 1
       imgNum = max; 
    else
        imgNum = imgNum -1;
    end
end

[cont1,interpCont1] = getBorder(img,pts(1,:));
[cont2,interpCont2] = getBorder(img,pts(2,:));
[cont3,interpCont3] = getBorder(img,pts(3,:));

delete(data.imgPlot);
data.imgPlot = imshow(img(:,:,1,imgNum)); hold on;

delete(data.contPlot1);
delete(data.contPlot2);
delete(data.contPlot3);
delete(data.interPlot1);
delete(data.interPlot2);
delete(data.interPlot3);

data.contPlot1 = plot(cont1(:,1),cont1(:,2));
data.contPlot2 = plot(cont2(:,1),cont2(:,2),'r');
data.contPlot3 = plot(cont3(:,1),cont3(:,2),'g');
data.interPlot1 = plot(interpCont1(:,1),interpCont1(:,2));
data.interPlot2 = plot(interpCont2(:,1),interpCont2(:,2),'r');
data.interPlot3 = plot(interpCont3(:,1),interpCont3(:,2),'g');


data.imgNum = imgNum;
set(fig,'UserData',data);
end













