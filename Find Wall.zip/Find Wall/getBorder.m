function [ cont,interpolatedContour ] = getBorder( img,pt )
%GETBORDER Summary of this function goes here
%   Detailed explanation goes here
% img has two dimensions
% pt is 2d point
pixInt = 1;
dist = 1;
contPts = [];
intMean = 1;
for theta = 1:360
    while (pixInt < 60) & ((pixInt ~= 0)|(intMean>.1));
        y = ceil(pt(1) + dist*cosd(theta));
        x = ceil(pt(2) + dist*sind(theta));
        pixInt = img(x,y);
        if pixInt == 0
            xMean = [x-20,x+20];
            yMean = [y-20,y+20];
            intMean = mean(img(xMean(1):xMean(2),yMean(1):yMean(2)));
        end
        dist = dist+1;
    end
    pixInt = 1;
    contPts = [contPts;x,y];
    dist = 0;
end
% Do interpolation to smooth curve
x = contPts(:,2);
y = contPts(:,1);
continx = [x;x(1:40)];
continy = [y;y(1:40)];
xRloess = smooth(continx,.1,'rloess');
yRloess = smooth(continy,.1,'rloess');
xRloess = [xRloess(40:400);xRloess(40)];
yRloess = [yRloess(40:400);yRloess(40)];
interpolatedContour = [xRloess,yRloess];
cont = [contPts(:,2),contPts(:,1)];

end

