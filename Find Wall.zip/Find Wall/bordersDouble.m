clear; close
imgLet = 'parLongImgs/4358';

img = dicomread(imgLet);
si = size(img);
% if si(4) <25
%     img = img(:,:,1,1:end);
% else
    img = img(:,:,1,1:25);
% end
imgNum = 1;
max = length(img(1,1,1,:));

imshow(img(:,:,:,imgNum));

jk = 2;
for gg = 1:3
    while jk ~= 1
        [ptx,pty,jk] = ginput(1);
        pt = [ptx, pty];
        if jk == 29
            imgNum = imgNum + 1;
            replotI(gcf,img,imgNum);
        elseif jk == 28
            imgNum = imgNum -1;
            replotI(gcf,img,imgNum);
        end
    end
    if gg == 1
        pt1 = pt;
    elseif gg == 2
        pt2 = pt;
    elseif gg == 3
        pt3 = pt;
    end
    jk = 0;
end

for i = 1:max
    tic
    [contLV(:,:,i),contLVint(:,:,i)] = borderDet(img(:,:,1,i),pt3,'LA');
    [contLA(:,:,i),contLAint(:,:,i)] = borderDet(img(:,:,1,i),pt2,'LA');
    [contAo(:,:,i),contAoint(:,:,i)] = borderDet(img(:,:,1,i),pt1,'LA');
    toc
end


% figure
% img = dicomread(imgLet);
% imshow(img(:,:,:,num));hold on;
%
% % plot(contLVint(:,1),contLVint(:,2),'b');hold on;
% % plot(contLAint(:,1),contLAint(:,2),'r');hold on;
%
% plot(contLV(:,1),contLV(:,2),'c');hold on;
% plot(contLA(:,1),contLA(:,2),'m');hold on;
% plot(contAo(:,1),contAo(:,2),'g');


% r = 29; l = 28
jk = 2;
button = 2;
imgNum = 1;
while button ~= 32
    d = imshow(img(:,:,:,imgNum));hold on;
    
    a = plot(contLV(:,1,imgNum),contLV(:,2,imgNum),'cx');hold on;
    b = plot(contLA(:,1,imgNum),contLA(:,2,imgNum),'mx');hold on;
    c = plot(contAo(:,1,imgNum),contAo(:,2,imgNum),'gx');
    
    [x,y,button] = ginput(1);
%     keyboard
    if (button == 29 & imgNum == max)
        imgNum = 1;
    elseif (button == 28 & imgNum == 1)
        imgNum = max;
    elseif button == 28
        imgNum = imgNum-1;
    else
        imgNum = imgNum+1;
    end
end


range = ginput(6);

% iterate through all points of LV contour and find the points in the
% dataset closest to ginput points
dist1 = 100;
dist2 = 100;
for j = 1:3
    switch j
        case 1
            contour = contLA;
            range1 = range(1,:);
            range2 = range(2,:);
        case 2
            contour = contLV;
            range1 = range(3,:);
            range2 = range(4,:);
        case 3
            contour = contAo;
            range1 = range(5,:);
            range2 = range(6,:);
    end
    
    for i = 1:length(contour(:,1,imgNum))
        if norm(contour(i,:,imgNum)-range1) < dist1
            dist1 = norm(contour(i,:,imgNum)-range1);
            smallIndLV = i;
        end
        if norm(contour(i,:,imgNum)-range2) < dist2
            dist2 = norm(contour(i,:,imgNum)-range2);
            largeIndLV = i;
        end
        
        %         Save the ranges:
        switch j
            case 1
                rangeLA = [smallIndLV,largeIndLV];
            case 2
                %                 Check if large ind > 100, because low-small is near theta
                %                 = 0
                if largeIndLV > 100
                    rangeLV = [largeIndLV,smallIndLV];
                else
                    rangeLV = [smallIndLV,largeIndLV];
                end
            case 3
                rangeAo = [smallIndLV,largeIndLV];
        end        
    end
end

newData = [contLA(rangeLA(1):rangeLA(2),:,imgNum);...
           contLV(rangeLV(1):rangeLV(2),:,imgNum);
           contLV(rangeAo(1):rangeAo(2),:,imgNum)];

plot(newData(:,1),newData(:,2),'yx');

