function [ cont,contInt ] = borderDet( img,pt,which )
% inputs
% img is the image that you want to detect tissue border of
% pt is a point inside of the cavity of interest
si = size(img);
if strcmp(which,'LA')
    which = -1;
else
    which = 1;
end

% imshow(img(:,:,:,imgNum));
% 
% jk = 2;
% while jk ~= 1
%     [ptx,pty,jk] = ginput(1);
%     pt = [ptx, pty];
%     if jk == 29
%        imgNum = imgNum + 1;
%        replotI(gcf,img,imgNum);
%     elseif jk == 28
%         imgNum = imgNum -1;
%         replotI(gcf,img,imgNum);
%     end
% end

% a = size(img);
% if length(a)~=2
%     img = img(:,:,1,imgNum);
% end

% outputs
% cont is the contour of the border of interest
pixInt = 1;
dist = 1;
contPts = [];
intMean = 1;
t = 0;
for theta = 1:360
    while (t == 0) & ((pixInt ~= 0)|(intMean>.1))%setting thresholds.  First expression 60 greater than noise...
        %Second expression - check to see if you are going outside image border
        y = ceil(pt(1) + dist*cosd(theta)); %distance in y direction to current pixel
        x = ceil(pt(2) + dist*sind(theta)); %distance in x direction to current pixel
        
        if x <1 | y<1 | x>si(1) | y>si(2)
           break 
        end
        pixInt = img(x,y);
        
        if pixInt == 0
            xMean = [x-20,x+20];
            yMean = [y-20,y+20];
            try intMean = mean(img(xMean(1):xMean(2),yMean(1):yMean(2)));
                intMean = mean(img(xMean(1):xMean(2),yMean(1):yMean(2)));
            catch
%                 keyboard
            end
        else
            switch which
                case 1
                    if x>pt(2) %generally below the original point can have higher threshold
                        if pixInt>60
                            t = 1;
                            
                        else
                            t = 0;
                        end
                    else
                        if pixInt>50
                            t = 1;
                        else
                            t = 0;
                        end
                    end
                case -1
                    if x<pt(2) %generally below the original point can have higher threshold
                        if pixInt>60
                            t = 1;
                            
                        else
                            t = 0;
                        end
                    else
                        if pixInt>50
                            t = 1;
                        else
                            t = 0;
                        end
                    end                    
            end
        end
        dist = dist+1;
    end
    pixInt = 1;
    contPts = [contPts;x,y];
    dist = 0;
    t = 0;
end
% Do interpolation to smooth curve
x = contPts(:,2);
y = contPts(:,1);
continx = [x;x(1:40)];
continy = [y;y(1:40)];
xRloess = smooth(continx,.1,'rloess');
yRloess = smooth(continy,.1,'rloess');
xRloess = [xRloess(40:400);xRloess(40)];
yRloess = [yRloess(40:400);yRloess(40)];
% figure
% % imshow(img);hold on;
% plot(xRloess,yRloess,'g');
% plot(contPts(:,2),contPts(:,1));
% close all
cont = [contPts(:,2),contPts(:,1)];
contInt = [xRloess,yRloess];
end


function [] = replotI(fig,img,num)
figure(fig);
imshow(img(:,:,:,num));
end



